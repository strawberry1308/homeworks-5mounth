import React from 'react'

export const SinglePost = () => {
  return (
    <div>SinglePost</div>
  )
}
