import React from 'react'

export const ProfilePage = () => {
  return (
    <div>ProfilePage</div>
  )
}
