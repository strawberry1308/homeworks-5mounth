import React from 'react'

export const MainPage = () => {
  return (
    <div>MainPage</div>
  )
}
